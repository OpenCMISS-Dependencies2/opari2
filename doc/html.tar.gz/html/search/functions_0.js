var searchData=
[
  ['ctcstring2regioninfo',['ctcString2RegionInfo',['../pomp2__region__info_8h.html#ada8fce980385bdc6598a889bc2ba7892',1,'pomp2_region_info.h']]],
  ['ctcstring2userregioninfo',['ctcString2UserRegionInfo',['../pomp2__user__region__info_8h.html#adf68daa6bcbb49e313189a50c692217a',1,'pomp2_user_region_info.h']]]
];
